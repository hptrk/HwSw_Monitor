﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;


namespace HwSw_Monitor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer idozito = new DispatcherTimer();
        public MainWindow()
        {
            InitializeComponent();
            idozito.Interval = TimeSpan.FromSeconds(1);
            idozito.Tick += Monitor;
            Beolvas();
            Drivers();
        }
        List<Software> swlist = new List<Software>();
        public void Beolvas()
        {
            string uninstall = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall";
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(uninstall))
            {
                foreach (string item in key.GetSubKeyNames())
                {
                    using (RegistryKey subkey = key.OpenSubKey(item))
                    {
                        var filename = subkey.GetValue("DisplayName");
                        var version = subkey.GetValue("DisplayVersion");
                        if (filename != null)
                        {
                            if (version != null)
                            {
                                string fn = filename.ToString();
                                string v= version.ToString();
                                string sor = fn + "," + v;
                                swlist.Add(new Software(sor));
                            }
                        }
                    }
                }
            }
            foreach (var item in swlist)
            {
                szoftverdata.Items.Add(item);
            }
        }


        List<Drivers> driverek = new List<Drivers>();
        public void Drivers()
        {
            ManagementObjectSearcher objSearcher = new ManagementObjectSearcher("Select * from Win32_PnPSignedDriver");

            ManagementObjectCollection objCollection = objSearcher.Get();

            foreach (ManagementObject obj in objCollection)
            {
                string info = Convert.ToString(obj["DeviceName"]) + "," + Convert.ToString(obj["Manufacturer"]) + "," + Convert.ToString(obj["DriverVersion"]);
                driverek.Add(new Drivers(info));
            }
            driverlista.DataContext = driverek;
            foreach (var item in driverek)
            {
                driverlista.Items.Add(item);
            }
        }

        private void stop_Click(object sender, RoutedEventArgs e)
        {
            idozito.Stop();
        }

        private void start_Click(object sender, RoutedEventArgs e)
        {
            idozito.Start();
        }

        PerformanceCounter memorias = new PerformanceCounter("Memory", "% Committed Bytes In Use");
        PerformanceCounter memoriaa = new PerformanceCounter("Memory", "Available MBytes");
        PerformanceCounter cpu = new PerformanceCounter("Processor", "% Processor Time", "_Total");

        public void Monitor(object sender, EventArgs e)
        {
            usedram.Content = "Felhasznált memória: " + Math.Round(memorias.NextValue()).ToString() + "%";
            ram.Content = "Memória: " + memoriaa.NextValue().ToString() + "Mb";
            cputime.Value = cpu.NextValue();
            idozito.Stop();
            idozito.Start();
        }

       
        
        private void hardverbe_Click(object sender, RoutedEventArgs e)
        {
            ManagementObjectSearcher videocontrol = new ManagementObjectSearcher("SELECT * FROM Win32_VideoController");
            foreach (ManagementObject item in videocontrol.Get())
            {

                videocard.Content = "Videókártya: " + item["Name"] + ", Driver verziója: " + item["DriverVersion"];
            }
            ManagementObjectSearcher cpu = new ManagementObjectSearcher("SELECT * FROM Win32_Processor");
            foreach (ManagementObject item in cpu.Get())
            {
                processzor.Content = "Processzor: " + item["Name"];
            }
            ManagementObjectSearcher alaplap = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_BaseBoard");
            foreach (ManagementObject item in alaplap.Get())
            {
                motherboard.Content = "Alaplap gyártója, típusa: " + item["Manufacturer"] + ", " + item["Name"];
            }
            ManagementObjectSearcher memory = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMemory");
            foreach (ManagementObject item in memory.Get())
            {
                memoria.Content = "Memória: " + item["Name"];
            }
            ManagementObjectSearcher monitor = new ManagementObjectSearcher("SELECT * FROM Win32_DesktopMonitor");
            foreach (ManagementObject item in monitor.Get())
            {
                Monitoreszk.Content = "Monitor: " + item["Name"];
            }
        }

    }
}
